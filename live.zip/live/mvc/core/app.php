<?php
    class App{
        function __construct(){
            echo $_GET["url"];
        }
    }
?>