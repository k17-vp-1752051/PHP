<?php
require_once "./mvc/core/app.php"
?>